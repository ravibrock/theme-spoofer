// v2 requires actual background script content
// this just keeps it alive, does nothing rn
console.log("theme spoofer background script loaded");
